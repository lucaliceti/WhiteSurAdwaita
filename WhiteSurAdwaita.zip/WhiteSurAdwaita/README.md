# WhiteSurAdwaita
Gnome icon theme that incorporates the Adwaita icon theme and the White-Sur theme is a beautiful and cohesive set of icons that combines the classic look of Adwaita with the modern, sleek design of White-Sur.
